/**********************************************************************c
* Author: Marcin Dec
* Date: 17.02.2015
* FileName:        Timer1.h
* Dependencies:    Timer1.c
* Processor:       dsPIC30F6013A
* Compiler:        MPLAB� C30 v3.00 or higher
*
************************************************************************/

extern void Timer1Init(void);

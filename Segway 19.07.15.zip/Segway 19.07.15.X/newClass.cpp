/* 
 * File:   newClass.cpp
 * Author: Marcin
 * 
 * Created on 2 maj 2015, 10:12
 */

#include "newClass.h"

newClass::newClass() {
}

newClass::newClass(const newClass& orig) {
}

newClass::~newClass() {
}


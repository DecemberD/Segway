/* 
 * File:   newClass.h
 * Author: Marcin
 *
 * Created on 2 maj 2015, 10:12
 */

#ifndef NEWCLASS_H
#define	NEWCLASS_H

class newClass {
public:
    newClass();
    newClass(const newClass& orig);
    virtual ~newClass();
private:

};

#endif	/* NEWCLASS_H */

